package com.springbook.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springbook.biz.common.JDBCUtil;
import com.springbook.biz.user.UserService;
import com.springbook.biz.user.UserVO;

@Repository("userDAO")
public class UserDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	private final String USER_GET = "select * from users where id=? and password=? ";
	private final String USER_LIST = "select * from users order by id";
	private final String USER_INSERT = "insert into users values (?,?,?,?)";
	private final String USER_UPDATE = "update users set password=?, role=? where id=?";
	private final String USER_DELETE = "delete from users where id=?";
	
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		try {
			System.out.println("===> JDBC로 getUser() 기능 처리");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_GET);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				user = new UserVO();
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setRole(rs.getString("role"));
			}
			
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return user;
	}
	
	public List<UserVO> getUserList(UserVO vo) {
		List<UserVO> userList = null;
		try {
			System.out.println("===> JDBC로 getUserList() 기능 처리");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_LIST);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				userList = new ArrayList();
				UserVO user = new UserVO();
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setRole(rs.getString("role"));
				userList.add(user);
			}
			
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return userList;
	}
	
	
	public int insertUser(UserVO vo) {
		int result = 0;
		try {
			System.out.println("===> JDBC로 insertUser() 기능 처리");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_INSERT);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getName());
			stmt.setString(4, vo.getRole());
			result = stmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			JDBCUtil.close(stmt, conn);
		}
		return result;
	}
	
	public int updateUser(UserVO vo) {
		int result = 0;
		try {
			System.out.println("===> JDBC로 updateUser() 기능 처리");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_UPDATE);
			stmt.setString(1, vo.getPassword());
			stmt.setString(2, vo.getRole());
			stmt.setString(3, vo.getId());
			result = stmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			JDBCUtil.close(stmt, conn);
		}
		return result;
	}
	
	public int deleteUser(UserVO vo) {
		int result = 0;
		try {
			System.out.println("===> JDBC로 deleteUser() 기능 처리");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_DELETE);
			stmt.setString(1, vo.getId());
			result = stmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			JDBCUtil.close(stmt, conn);
		}
		return result;
	}
	
}
